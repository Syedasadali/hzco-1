"Simple Calculator in JAvaScript Using HTML5 CSS3 and Javascript Created on 14/6/2016 by Bilal Khan" 

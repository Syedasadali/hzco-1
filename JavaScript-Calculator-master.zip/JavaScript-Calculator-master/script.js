/****************************************
Created by Bilal Khan on 14/6/2016
Simple Calculator using HTML5 CSS3 and JS
*****************************************/

var one = document.getElementById("one");
var two = document.getElementById("two");
var three = document.getElementById("three");
var four = document.getElementById("four");
var five = document.getElementById("five");
var six = document.getElementById("six");
var seven =  document.getElementById("seven");
var eight = document.getElementById("eight");
var nine = document.getElementById("nine");
var plus = document.getElementById("plus");
var minus = document.getElementById("minus");
var multi = document.getElementById("multiply");
var devide = document.getElementById("devide");
var equal = document.getElementById("equal");
var display = document.getElementById("display");
var clear = document.getElementById("clear");

var operatorPressed = false;
var firstNumber = 0;
var secondNumber = 0;

one.onclick = function(){
   if(operatorPressed){
      display.value = 1;
   }
   else {
      display.value += 1;
   }
   operatorPressed = false;
}

two.onclick = function(){
   if(operatorPressed){
      display.value = 2;
   }
   else {
      display.value += 2;
   }
   operatorPressed = false;
}

three.onclick = function(){
    if(operatorPressed) {
        display.value = 3;
    } else {
        display.value += 3;
    }
    operatorPressed = false;
}

four.onclick = function() {
    if (operatorPressed) {
        display.value = 4;
    } else {
        display.value += 4;
    }
    operatorPressed = false;
}

five.onclick = function(){
    if(operatorPressed){
        display.value = 5;
    } else {
        display.value += 5;
    }
    operatorPressed = false;
}

six.onclick = function(){
    if(operatorPressed){
        display.value = 6;
    } else{
        display.value += 6;
    }
    operatorPressed = false;
}

seven.onclick = function() {
    if (operatorPressed) {
        display.value = 7;
    }else {
        display.value += 7;
    }
    operatorPressed = false;
}

eight.onclick = function(){
    if(operatorPressed){
        display.value = 8;
    } else {
        display.value += 8;
    }
    operatorPressed = false;
}

nine.onclick = function(){

    if(operatorPressed){
        display.value = 9;
    } else {
        display.value += 9;
    }
    operatorPressed = false;
}

zero.onclick = function(){

    if(operatorPressed){
        display.value = 0;
    } else {
        display.value += 0;
    }
    operatorPressed = false;
}


clear.onclick = function(){
    operatorPressed = true;
    firstNumber = display.value;
    display.value = "";
     equal.onclick = function(){
         secondNumber = display.value;
         display.value = "";
     }
}

plus.onclick = function(){
   operatorPressed = true;
   firstNumber = parseInt(display.value);
   display.value = display.value +"+";
    equal.onclick = function(){
        secondNumber = parseFloat(display.value);
        display.value =  firstNumber + secondNumber ;
    }
}

minus.onclick = function(){
    operatorPressed = true;
    firstNumber = parseInt(display.value);
    display.value = "-";
     equal.onclick = function(){
        secondNumber = parseFloat(display.value);
        display.value = firstNumber - secondNumber;
     }
}

multi.onclick = function(){
    operatorPressed = true;
    firstNumber = parseInt(display.value);
    display.value = "x";
     equal.onclick = function(){
         secondNumber = parseFloat(display.value);
         display.value = firstNumber * secondNumber;
     }
}

devide.onclick = function(){
    operatorPressed = true;
    firstNumber = parseInt(display.value);
    display.value = "/";
     equal.onclick = function(){
         secondNumber = parseFloat(display.value);
         display.value = firstNumber / secondNumber;
     }
}


/*************
 End of Scipt
 ./Bye
**************/